# utilscognigen

`utilscognigen` provides utility functions for R and RStudio at Cognigen Corporation. This package facilitates creation, execution, and review of R files.

Load it with:
```r
library(utilscognigen)
```

Install the development version with:
```r
remotes::install_gitlab(repo = "r/utilscognigen", host = "gitlab.cognigencorp.com")
```

# Functionality

