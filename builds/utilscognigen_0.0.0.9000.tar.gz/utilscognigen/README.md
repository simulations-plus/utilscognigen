# utilscognigen

# Overview

`utilscognigen` provides utility functions for R and RStudio at Cognigen Corporation. This package facilitates creation, execution, and review of R files. This package also provides an interface for interacting with the Cognigen file system and sponsor directory structure.

Load it with:
```r
library(utilscognigen)
```

# Functionality

## Creating R Files

TODO

## Executing R Files

TODO

## Reviewing R Files

TODO

## Interacting with the Cognigen File System

TODO
