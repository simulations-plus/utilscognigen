# Copyright 2020-2022-06-30 Cognigen Corporation, a Simulations Plus Company

.onLoad <- function(libname, pkgname) {
  
  packageStartupMessage(
    sprintf(
      'Loading utilscognigen Version %s',
      utils::packageVersion('utilscognigen')
    )
  )
  
}

# quiets R CMD check note
utils::globalVariables('ioenv')
