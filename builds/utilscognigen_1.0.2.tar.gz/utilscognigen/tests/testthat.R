library(testthat)
library(utilscognigen)

test_check("utilscognigen")
