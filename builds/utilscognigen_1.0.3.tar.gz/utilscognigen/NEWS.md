# utilscognigen 1.0.3

* Now accepts Quarto documents as input where R or R Markdown files are accepted.
* Added functions to view project management sites: `browse_project_gantt` and `browse_project_tracker`.

# utilscognigen 1.0.2

* Updated to host publicly on GitHub.

# utilscognigen 1.0.1

* Improved output of `recorded_io` in R Markdown output.
* R files are now accepted input to `render`.

# utilscognigen 1.0.0

* Added a `NEWS.md` file to track changes to the package.
